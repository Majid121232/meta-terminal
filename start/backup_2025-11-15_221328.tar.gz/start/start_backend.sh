#!/bin/sh
# Advanced Backend Starter with PID tracking
PORT=5253
LOG="logs/backend.log"
PIDFILE="run/backend.realpid"
mkdir -p logs run

echo "[BOOT] Backend starting at $(date)" >>"$LOG"

if command -v httpd >/dev/null 2>&1; then
  httpd -f -p "127.0.0.1:$PORT" >>"$LOG" 2>&1 &
  echo $! > "$PIDFILE"
elif command -v python3 >/dev/null 2>&1; then
  python3 -m http.server "$PORT" --bind 127.0.0.1 >>"$LOG" 2>&1 &
  echo $! > "$PIDFILE"
else
  ( while true; do echo "backend alive"; sleep 60; done ) >>"$LOG" 2>&1 &
  echo $! > "$PIDFILE"
fi

# نگه داشتن اسکریپت زنده تا orchestrator PID درست رو بگیره
tail -f /dev/null
