#!/bin/sh
# Advanced Frontend Starter with PID tracking
PORT=3000
LOG="logs/frontend.log"
PIDFILE="run/frontend.realpid"
mkdir -p logs run

echo "[BOOT] Frontend starting at $(date)" >>"$LOG"

if command -v httpd >/dev/null 2>&1; then
  httpd -f -p "127.0.0.1:$PORT" >>"$LOG" 2>&1 &
  echo $! > "$PIDFILE"
elif command -v python3 >/dev/null 2>&1; then
  python3 -m http.server "$PORT" --bind 127.0.0.1 >>"$LOG" 2>&1 &
  echo $! > "$PIDFILE"
else
  ( while true; do echo "frontend alive"; sleep 60; done ) >>"$LOG" 2>&1 &
  echo $! > "$PIDFILE"
fi

tail -f /dev/null
